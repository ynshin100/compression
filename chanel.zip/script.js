$(function () {
  $(".imgbox").parallaxScroll({
    friction: 0.2,
    // 0이면 배경이미지가 컨텐츠를 따라서 같이 스크롤이 됨. 1이면 배경은 완전히 고정이되고, 컨텐츠만 스크롤이 됨
  });
});
